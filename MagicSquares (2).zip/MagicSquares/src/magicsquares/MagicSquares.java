/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package magicsquares;

import java.util.Scanner;

/**
 *
 * @author Mbali Mthethwa
 */
public class MagicSquares 
{
    int[][] sqaures;
    int x,y;
    int count;
    
    private void addSize(int index)
    {
        sqaures = new int[index][index];
        count = 1;
    }
    
    private boolean validOddNumber(int number)
    {
        if(number % 2 == 1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    private void plotMiddle()
    {
        this.y = sqaures.length / 2;
        this.x = 0;
        
        sqaures[x][y] = count;
        count ++;
    
    }
    
    private void moveToNext()
    {
        int tempx = x;
        int tempy = y;
        if(this.y + 1 > sqaures.length -1 )
        {
            tempy = 0;
        }
        else
        {
            tempy +=1;
        }
        
        if(this.x -1 < 0)
        {
            tempx = sqaures.length - 1;
                   
        }
        else
        {
            tempx -= 1;
        }
       
        if(noValueExist(tempx, tempy))
        {
            x = tempx;
            y = tempy;
            sqaures[x][y] = count;
            count ++;
        }
        else
        {
            moveDown();
        }
        
    
    }
    
    private void moveDown()
    {
        
        
        x = x + 1;
       
        sqaures[x][y] = count;
        
        count ++;
    }
    
   private void printMagicSquares()
    {
        for(int x = 0; x < sqaures.length; x++)
        {
            System.out.println("----------------------------------");
            for(int y = 0; y < sqaures.length; y++)
            {
                System.out.print(sqaures[x][y] + " | ");
            }
            System.out.println("");
        }
        System.out.println("----------------------------------");
    }
    
    public boolean noValueExist(int xValue,int yValue)
    {
        if(sqaures[xValue][yValue] == 0)
        {
            return true;
        }
        else{
            return false;
        }
    }
 
    


    
    
    public static void main(String[] args)
    {
        // TODO code application logic here
        
        MagicSquares magicSquares = new MagicSquares();
        boolean valid;
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter odd number to create a magic square. Enter 3 or 5 or 7 or 9 or 11 etc ");
        int input = scan.nextInt();
        
        do
        {
            if( magicSquares.validOddNumber(input))
            {
                valid = true;
                magicSquares.addSize(input);
                magicSquares.plotMiddle();
                int loops = input * input - 1;
                
                for(int i = 0; i < loops;i++)
                {
                    magicSquares.moveToNext();
                
                }
                
                magicSquares.printMagicSquares();
               
                
               
                       
                    
            }
            else{
            
                valid = false;
                System.out.print("Enter odd number to create a magic square. Enter 3 or 5 or 7 or 9 or 11 etc ");
                input = scan.nextInt();
            }
               
            
        }
        while(valid == false);
        
        
       
    
    }
}